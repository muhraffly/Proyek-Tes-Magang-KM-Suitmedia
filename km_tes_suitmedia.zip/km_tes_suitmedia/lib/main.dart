import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:km_tes_suitmedia/user.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: FirstScreen(),
    );
  }
}

class FirstScreen extends StatefulWidget {
  @override
  _FirstScreenState createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  TextEditingController nameController = TextEditingController();
  TextEditingController sentenceController = TextEditingController();
  String resultMessage = "";

  bool isPalindrome(String text) {
    String cleanText = text.replaceAll(" ", "").toLowerCase();
    String reversedText = cleanText.split('').reversed.join('');
    return cleanText == reversedText;
  }

  void checkPalindrome() {
    String sentence = sentenceController.text;
    bool isPalindromic = isPalindrome(sentence);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Palindrome Check'),
          content: Text(isPalindromic ? 'Palindrome' : 'Not Palindrome'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void goToSecondScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SecondScreen(
          name: nameController.text,
          onUserSelected: (userName) {
          },
        ),
      ),
    );

  }

  @override
  Widget build(BuildContext context) {
    double inputWidth = MediaQuery.of(context).size.width - 32;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/background.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 116,
                height: 116,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/image_first_screen.png'),
                    fit: BoxFit.cover,
                  ),
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(height: 50),
              SizedBox(
                width: inputWidth,
                height: 48,
                child: TextField(
                  controller: nameController,
                  style: TextStyle(
                    color: Colors.black,
                    fontFamily: 'Poppins',
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Name',
                    floatingLabelBehavior: FloatingLabelBehavior.never,
                    labelStyle: TextStyle(
                      color: Color(0xFF6867775C),
                      fontFamily: 'Poppins',
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10),
              SizedBox(
                width: inputWidth,
                height: 48,
                child: TextField(
                  controller: sentenceController,
                  style: TextStyle(
                    color: Colors.black,
                    fontFamily: 'Poppins',
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Palindrome',
                    floatingLabelBehavior: FloatingLabelBehavior.never,
                    labelStyle: TextStyle(
                      color: Color(0xFF6867775C),
                      fontFamily: 'Poppins',
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
              SizedBox(
                width: inputWidth,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    checkPalindrome();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2B637B), // Background color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12), // BorderRadius
                    ),
                    padding: EdgeInsets.fromLTRB(85.08, 12.35, 85.08, 12.35), // Padding
                    minimumSize: Size(310, 41), // Size
                  ),
                  child: Text('CHECK', style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Poppins',
                      fontSize: 14,
                      fontWeight: FontWeight.w500
                  )),
                ),
              ),
              SizedBox(height: 10),
              SizedBox(
                width: inputWidth,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    goToSecondScreen();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2B637B), // Background color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12), // BorderRadius
                    ),
                    padding: EdgeInsets.fromLTRB(85.08, 12.35, 85.08, 12.35), // Padding
                    minimumSize: Size(310, 41), // Size
                  ),
                  child: Text('NEXT', style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Poppins',
                      fontSize: 14,
                      fontWeight: FontWeight.w500
                  )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SecondScreen extends StatefulWidget {
  final String name;
  final Function(User) onUserSelected;

  SecondScreen({required this.name, required this.onUserSelected});

  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  User? selectedUser;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Image.asset(
            'assets/back_button.png',
            width: 48,
            height: 48,
          ),
          onPressed: () {
            // Handle back button press
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Second Screen',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFF04021D),
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Welcome',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 12,
                fontWeight: FontWeight.w400,
                letterSpacing: 0,
              ),
            ),
            Text(widget.name ?? '',
              style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0
              ),
            ),
            SizedBox(height: 50),
            Container(
              height: MediaQuery.of(context).size.height * 0.5,
              child: Center(
                child: Text(
                  selectedUser != null
                      ? '${selectedUser!.firstName} ${selectedUser!.lastName}'
                      : 'Selected User Name',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0,
                  ),
                ),
              ),
            ),
            Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ThirdScreen(
                        onUserSelected: (user) {
                          setState(() {
                            selectedUser = user;
                          });
                        },
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF2B637B), // Background color
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12), // BorderRadius
                  ),
                  padding: EdgeInsets.fromLTRB(85.08, 12.35, 85.08, 12.35), // Padding
                  minimumSize: Size(310, 41), // Size
                ),
                child: Text(
                  'Choose a User',
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Poppins',
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ThirdScreen extends StatefulWidget {
  final Function(User) onUserSelected;

  ThirdScreen({required this.onUserSelected});

  @override
  _ThirdScreenState createState() => _ThirdScreenState();
}

class _ThirdScreenState extends State<ThirdScreen> {
  List<User> users = [];
  int page = 1;
  int perPage = 10;

  @override
  void initState() {
    super.initState();
    fetchUsers();
  }

  Future<void> fetchUsers() async {
    final response = await http.get(
      Uri.parse('https://reqres.in/api/users?page=$page&per_page=$perPage'),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      List<dynamic> userList = data['data'];

      setState(() {
        users.addAll(userList.map((user) => User.fromJson(user)).toList());
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Image.asset(
            'assets/back_button.png',
            width: 48,
            height: 48,
          ),
          onPressed: () {
            // Handle back button press
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Third Screen',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFF04021D),
          ),
        ),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() {
            users.clear();
            page = 1;
          });
          await fetchUsers();
        },
        child: ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(
                '${users[index].firstName} ${users[index].lastName}',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                  height: 1.5,
                  color: Color(0xFF04021D),
                ),
              ),
              subtitle: Text(
                'Email: ${users[index].email}',
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 10,
                    height: 1.5, // Line height,
                    color: Color(0xFF686777)
                ),
              ),
              leading: Container(
                width: 49.0,
                height: 49.0,
                margin: EdgeInsets.only(top: 16.0, left: 18.0),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(users[index].avatar),
                  ),
                ),
              ),
              onTap: () {
                widget.onUserSelected(users[index]);
                Navigator.pop(context);
              },
            );
          },
        ),
      ),
    );
  }
}