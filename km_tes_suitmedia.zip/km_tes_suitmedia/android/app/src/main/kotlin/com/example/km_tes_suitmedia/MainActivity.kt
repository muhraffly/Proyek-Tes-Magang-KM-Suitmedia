package com.example.km_tes_suitmedia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
